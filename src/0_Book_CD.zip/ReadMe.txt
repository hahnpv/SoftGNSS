� 2006 Springer Science+Business Media, LLC 

This electronic component package is protected by federal copyright law 
and international treaty. If you wish to return this book and the 
electronic component package to Springer Science+Business Media, LLC, do 
not open the disc envelope or remove it from the book. Springer 
Science+Business Media, LLC, will not accept any returns if the package 
has been opened and/or separated from the book. The copyright holder 
retains title to and ownership of the package. U.S. copyright law 
prohibits you from making any copy of the entire electronic component 
package for any reason without the written permission of Springer 
Science+Business Media, LLC, except that you may download and copy the 
files from the electronic component package for your own research, 
teaching, and personal communications use. Commercial use without the 
written consent of Springer Science+Business Media, LLC, is strictly 
prohibited. Springer Science+Business Media, LLC, or its designee has 
the right to audit your computer and electronic components usage to 
determine whether any unauthorized copies of this package have been 
made. 

Springer Science+Business Media, LLC, or the author(s) makes no warranty 
or representation, either express or implied, with respect to this 
electronic component package or book, including their quality, 
merchantability, or fitness for a particular purpose. In no event will 
Springer Science+Business Media, LLC, or the author(s) be liable for 
direct, indirect, special, incidental, or consequential damages arising 
out of the use or inability to use the electronic component package or 
book, even if Springer Science+Business Media, LLC, or the author(s) has 
been advised of the possibility of such damages. 
